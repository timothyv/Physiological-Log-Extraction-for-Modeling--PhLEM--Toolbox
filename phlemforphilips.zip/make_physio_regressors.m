function [C, names] = make_physio_regressors(param,PhLEM,varargin)

% function [C, names] = make_physio_regressors(param,PhLEM,varargin)
% 
% The PhLEM tool for making appropriate regressors for your GLM;
% 
% Inputs:
% 
%     1) param     -> Flag for which field of the PhLEM structure
%                     to look at.  Default is 'RESP'
%     2) PhLEM     -> Either the PhLEM stucture itself or a pointer
%                     to the file itself.
%     3) opts      -> Series of opt commands to adjust defaults.
%     
%     OPTS:  
%       a)  'TR'  -> TR in seconds.  Default is 2.
%       b)  'DOSAVE' -> 1 to save the output (default), 0 otherwise
%       c)  'ana_type' -> Analysis type to perform.  Right now the 
%                         options are:
%              i)  'fourier' : Use fourier expansions (default)
%              ii) 'rate'    : Use the rate of events per TR;
%              iii)'amp'     : Use the amplitude of events in each TR;
% Outputs
% 
%     1) C     = A NxD array of resampled values, where N = the number of 
%                TRs in your session.
%     2) names = Cell array of names for each column in C.
%     
%
% Written by T. Verstynen, J. Diedrichsen, and J. Schlerf (Sept 2008)
% Liscensed under the GPL public license (version 3.0)

              
             
if nargin < 2 | isempty(PhLEM)

  % Use the SPM5 loader if it is available otherwise, you are using an
  % earlier version of SPM, so go back to spm_get
  if exist('spm_select')
    PhLEM = spm_select(1,'mat','Select Physio File');
  elseif exist('spm_get') % use SPM2 loader if it's here but not SPM5
    PhLEM = spm_get(1,'*.mat','Select Physio File');
  else    
  % if we don't have SPM, use matlab built-ins
    PhLEM = uigetfile('Select .mat PhLEM structure File');
  return
  end;
  
end;

%if ischar(PhLEM)
%    [fpath fname] = fileparts(PhLEM);
%    load(PhLEM);
%else
%    [fdir] = fileparts(pwd);
%    fname = sprintf('PhLEM_%d.m',param);
%end;

%if nargin < 1 | isempty(param)
%  param = 'RESP';
%  fprintf('No Parameter Identified: Assuming %s\n',param);
%end;

% DEFAULTS
TR = 2;
DOSAVE = 1;
ana_type = 'fourier';
plotflag = 1;
% param = 'RESP';

% Check for options to reset DEFAULTS
for v=1:2:length(varargin)
        eval(sprintf('%s = varargin{%d};',varargin{v},v+1));
end
%    optlabel = varargin{v};
%    optvalue = varargin{v+1};            
%    if ischar(optvalue)
%       eval(sprintf('%s = ''%s'';',optlabel,optvalue));
%    else
%        if isnumeric(optvalue), optvalue = num2str(optvalue); 
%        end
%        if isempty(optvalue) % if skipping a data type
%          eval(sprintf('%s = [];',optlabel));
%        else
%          eval(sprintf('%s = %s;',optlabel, optvalue));
%        end;
%    end
%end

% Get the target field of the PhLEM Structure
dtmp = eval(sprintf('PhLEM.%s',param));

% Setup TR markers
tr_sampling = round(PhLEM.Time(end)*1000/TR);
tr_timestamps = [0:(TR):PhLEM.Time(end)*1000-(TR/2)]/(mean(diff(PhLEM.Time))*1000);

switch ana_type
    case 'fourier'        
        C = [];
        for exp = dtmp.opts.phase_expand
            nphs = interp1(eval(sprintf('dtmp.phase%d',dtmp.opts.phase_expand(exp))),...
                tr_timestamps,'linear','extrap');            
            
            C = [C [sin(nphs)]'];
            C = [C [cos(nphs)]'];

            names{(exp-1)*2+1} = sprintf('FFT Exp %d: Sine %s',dtmp.opts.phase_expand(exp), param);
            names{(exp-1)*2+2} = sprintf('FFT Exp %d: Cosine %s',dtmp.opts.phase_expand(exp), param);
        end;
        
    case 'rate'
        C = histc(find(dtmp.events),tr_timestamps);
        names = sprintf('Rate: %s', param);
        
    case 'amp'
        
        amps = [dtmp.data./mean(dtmp.data)]-1;
        
        
        amps = dtmp.data(find(dtmp.events))./mean(dtmp.data) - 1;
        events = histc(find(dtmp.events),tr_timestamps);
        events(find(events)) = amps;
        C = events;
                
end;
        
if plotflag

    time = PhLEM.Time;
    maxlen = 10000;

    switch ana_type
        case 'fourier'    
            n_exps = length(dtmp.opts.phase_expand);
            cpos = []; xtick = []; xlabel = [];
            for e = 1:n_exps
                subpos = [1 2]+([4 4]*(e-1));
                subplot(n_exps,4,subpos);                
                x = eval(sprintf('dtmp.phase%d',dtmp.opts.phase_expand(e)));
                if length(x) > maxlen
                    x = x(1:maxlen);
                end;
                
                plot(time(1:length(x)),sin(x),'r',time(1:length(x)),cos(x),'b');
                title(sprintf('Fourier Expansion: %d',dtmp.opts.phase_expand(e)));
                ylabel('Time');
                
                cpos = [cpos [3 4]+(e-1)*[4 4]];
                xlabel = [xlabel {sprintf('sin%d',e), sprintf('cos%d',e)}];
                
            end;

            subplot(n_exps,4,cpos);
            imagesc(C);
            title('Regressor Values');
            set(gca,'XTick',[1:size(C,2)],'XTickLabel',xlabel);
            
            scr = get(0,'ScreenSize');
            pos = [0.2*scr(3) 0.15*scr(4) 0.5*scr(3) 0.7*scr(4)];
            set(gcf,'Position',pos);
            
    end;
end;
            
    
    
    